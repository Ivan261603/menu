function mostrarMenu(){
    var nav = document.getElementById("principal");
    nav.classList.toggle('mostrar');
}